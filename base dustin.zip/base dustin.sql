-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         11.3.0-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para tramites
CREATE DATABASE IF NOT EXISTS `tramites` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `tramites`;

-- Volcando estructura para tabla tramites.cliente
CREATE TABLE IF NOT EXISTS `cliente` (
  `idCliente` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(45) DEFAULT NULL,
  `Direccion` varchar(45) DEFAULT NULL,
  `Telefono` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idCliente`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Volcando datos para la tabla tramites.cliente: ~1 rows (aproximadamente)
REPLACE INTO `cliente` (`idCliente`, `Nombre`, `Direccion`, `Telefono`) VALUES
	(1, 'GMG COMERCIAL', 'ZONA 13', '20202020');

-- Volcando estructura para tabla tramites.embarque
CREATE TABLE IF NOT EXISTS `embarque` (
  `idEmbarque` int(11) NOT NULL AUTO_INCREMENT,
  `Eta` varchar(45) DEFAULT NULL,
  `DoctoEmbarque` varchar(45) DEFAULT NULL,
  `Duca` varchar(45) DEFAULT NULL,
  `Regimen` varchar(45) DEFAULT NULL,
  `Aduana` varchar(45) DEFAULT NULL,
  `Mercancias` varchar(45) DEFAULT NULL,
  `Retenciones` varchar(45) DEFAULT NULL,
  `SYL` varchar(45) DEFAULT NULL,
  `Selectivo` varchar(45) DEFAULT NULL,
  `Inicio` varchar(45) DEFAULT NULL,
  `Fin` varchar(45) DEFAULT NULL,
  `Estado` varchar(45) DEFAULT NULL,
  `Naviera` varchar(45) DEFAULT NULL,
  `Transporte` varchar(45) DEFAULT NULL,
  `Documentos Pendiente` varchar(45) DEFAULT NULL,
  `Gestor_idGestor` int(11) NOT NULL,
  `Cliente_idCliente` int(11) NOT NULL,
  PRIMARY KEY (`idEmbarque`) USING BTREE,
  KEY `fk_Embarque_Gestor1_idx` (`Gestor_idGestor`) USING BTREE,
  KEY `fk_Embarque_Cliente1_idx` (`Cliente_idCliente`) USING BTREE,
  CONSTRAINT `fk_Embarque_Cliente1` FOREIGN KEY (`Cliente_idCliente`) REFERENCES `cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Embarque_Gestor1` FOREIGN KEY (`Gestor_idGestor`) REFERENCES `gestor` (`idGestor`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Volcando datos para la tabla tramites.embarque: ~1 rows (aproximadamente)
REPLACE INTO `embarque` (`idEmbarque`, `Eta`, `DoctoEmbarque`, `Duca`, `Regimen`, `Aduana`, `Mercancias`, `Retenciones`, `SYL`, `Selectivo`, `Inicio`, `Fin`, `Estado`, `Naviera`, `Transporte`, `Documentos Pendiente`, `Gestor_idGestor`, `Cliente_idCliente`) VALUES
	(1, NULL, NULL, '301-4700000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'SEGUIMIENTO', NULL, NULL, NULL, 1, 1);

-- Volcando estructura para tabla tramites.estatus
CREATE TABLE IF NOT EXISTS `estatus` (
  `idEstatus` int(11) NOT NULL AUTO_INCREMENT,
  `Estatus` varchar(45) DEFAULT NULL,
  `Observacion` varchar(45) DEFAULT NULL,
  `Embarque_idEmbarque` int(11) NOT NULL,
  PRIMARY KEY (`idEstatus`) USING BTREE,
  KEY `fk_Estatus_Embarque_idx` (`Embarque_idEmbarque`) USING BTREE,
  CONSTRAINT `fk_Estatus_Embarque` FOREIGN KEY (`Embarque_idEmbarque`) REFERENCES `embarque` (`idEmbarque`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Volcando datos para la tabla tramites.estatus: ~0 rows (aproximadamente)

-- Volcando estructura para tabla tramites.gestor
CREATE TABLE IF NOT EXISTS `gestor` (
  `idGestor` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(45) DEFAULT NULL,
  `Telefono` varchar(45) DEFAULT NULL,
  `Aduana` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idGestor`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Volcando datos para la tabla tramites.gestor: ~1 rows (aproximadamente)
REPLACE INTO `gestor` (`idGestor`, `Nombre`, `Telefono`, `Aduana`) VALUES
	(1, 'lazaro', '50517389', 'Puerto Quetzal');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
